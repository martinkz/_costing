<template>
  <v-container>
    <v-row class="text-center">
      <v-col class="mb-4">
        <h1 class="display-2 font-weight-bold mb-3">Welcome to Vuetify</h1>
      </v-col>

      <v-col
        class="mb-5"
        cols="12"
      >
        <h2 class="headline font-weight-bold mb-3">
          Important Links
        </h2>

        <v-row justify="center">
          <a
            v-for="(link, i) in importantLinks"
            :key="i"
            :href="link.href"
            class="subheading mx-3"
            target="_blank"
          >
            {{ link.text }}
          </a>
        </v-row>
      </v-col>

      <!-- <v-col class="mb-5" cols="12">
        <v-select :items="items"  filled label="Filled style" @change="selectChange($event)"></v-select>
      </v-col> -->
    </v-row>

    <v-card>
      <v-toolbar color="cyan" dark flat>

        <v-toolbar-title>Dashboard</v-toolbar-title>

        <template v-slot:extension>
          <v-tabs v-model="tab" align-with-title>
            <v-tabs-slider color="cyan darken-3"></v-tabs-slider>

            <v-tab v-for="item in items2" :key="item">
              {{ item }}
            </v-tab>
          </v-tabs>
        </template>
      </v-toolbar>

      <v-tabs-items v-model="tab">
        <v-tab-item
          v-for="item in items2"
          :key="item"
        >
          <v-card flat>
            <v-card-text v-text="text"></v-card-text>
            <v-container>
              <v-select :items="items" filled label="Filled style" @change="selectChange($event)"></v-select>
            </v-container>
          </v-card>
        </v-tab-item>
      </v-tabs-items>
    </v-card>

  </v-container>
</template>

<script>
  export default {
    name: 'HelloWorld',

    data: () => ({
      items: ['Foo', 'Bar', 'Fizz', 'Buzz'],
      tab: null,
      items2: [
        'web', 'shopping', 'videos', 'images', 'news',
      ],
      text: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.',
      importantLinks: [
        {
          text: 'Documentation',
          href: 'https://vuetifyjs.com',
        },
        {
          text: 'Chat',
          href: 'https://community.vuetifyjs.com',
        },
        {
          text: 'Made with Vuetify',
          href: 'https://madewithvuejs.com/vuetify',
        },
        {
          text: 'Twitter',
          href: 'https://twitter.com/vuetifyjs',
        },
        {
          text: 'Articles',
          href: 'https://medium.com/vuetify',
        },
      ],
    }),

    methods: {
      selectChange(evt){
        console.log(evt);
      }
    }
  }
</script>
